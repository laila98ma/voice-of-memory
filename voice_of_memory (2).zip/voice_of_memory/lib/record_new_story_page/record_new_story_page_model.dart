import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/components/narrator_picker_sheet_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'record_new_story_page_widget.dart' show RecordNewStoryPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

class RecordNewStoryPageModel
    extends FlutterFlowModel<RecordNewStoryPageWidget> {
  ///  Local state fields for this page.

  bool warsSelected = true;

  bool? oldVillagesSelected = true;

  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // State field(s) for Checkbox widget.
  bool? checkboxValue1;
  // State field(s) for Checkbox widget.
  bool? checkboxValue2;
  AudioRecorder? audioRecorder;
  // Stores action output result for [Backend Call - API (uploadToCloudinary)] action in Container widget.
  ApiCallResponse? cloudinaryUrl;
  String? audioRecording;
  FFUploadedFile recordedFileBytes =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  // Stores action output result for [Backend Call - API (uploadToCloudinary)] action in Container widget.
  ApiCallResponse? cloudinaryUrl2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
