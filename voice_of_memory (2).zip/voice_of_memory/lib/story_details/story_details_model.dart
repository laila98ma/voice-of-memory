import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import '/index.dart';
import 'story_details_widget.dart' show StoryDetailsWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StoryDetailsModel extends FlutterFlowModel<StoryDetailsWidget> {
  ///  Local state fields for this page.

  bool isPlaying = false;

  int audioPosition = 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
