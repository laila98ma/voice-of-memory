// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// ignore_for_file: prefer_const_constructors
import 'package:just_audio/just_audio.dart';

class AudioPlayerWidget extends StatefulWidget {
  const AudioPlayerWidget({
    super.key,
    this.width,
    this.height,
    required this.audioUrl,
  });

  final double? width;
  final double? height;
  final String audioUrl;

  @override
  State<AudioPlayerWidget> createState() => _AudioPlayerWidgetState();
}

class _AudioPlayerWidgetState extends State<AudioPlayerWidget> {
  final AudioPlayer _player = AudioPlayer();
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _isLoading = true;
  double _speed = 1.0;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    try {
      await _player.setUrl(widget.audioUrl);
      _player.durationStream.listen((d) {
        if (d != null && mounted) setState(() => _duration = d);
      });
      _player.positionStream.listen((p) {
        if (mounted) setState(() => _position = p);
      });
      _player.playerStateStream.listen((s) {
        if (s.processingState == ProcessingState.completed) {
          _player.seek(Duration.zero);
          _player.stop();
        }
        if (mounted) setState(() {});
      });
    } catch (_) {}
    if (mounted) setState(() => _isLoading = false);
  }

  Future<void> _togglePlay() async {
    _player.playing ? await _player.pause() : await _player.play();
  }

  Future<void> _skip(int seconds) async {
    final t = _position + Duration(seconds: seconds);
    await _player.seek(t.isNegative
        ? Duration.zero
        : t > _duration
            ? _duration
            : t);
  }

  Future<void> _setSpeed(double s) async {
    setState(() => _speed = s);
    await _player.setSpeed(s);
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  double get _progress => _duration.inMilliseconds == 0
      ? 0
      : _position.inMilliseconds / _duration.inMilliseconds;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isPlaying = _player.playing;
    const primaryColor = Color(0xFF1A1A2E);

    return Container(
      width: widget.width ?? double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: _isLoading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // شريط التقدم
                GestureDetector(
                  onHorizontalDragUpdate: (details) {
                    final box = context.findRenderObject() as RenderBox;
                    final ratio = (details.localPosition.dx / box.size.width)
                        .clamp(0.0, 1.0);
                    _player.seek(Duration(
                        milliseconds:
                            (ratio * _duration.inMilliseconds).toInt()));
                  },
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: _progress,
                          minHeight: 5,
                          backgroundColor: Colors.grey.shade200,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(primaryColor),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(_fmt(_position),
                              style: TextStyle(
                                  fontSize: 12, color: Colors.grey.shade500)),
                          Text(_fmt(_duration),
                              style: TextStyle(
                                  fontSize: 12, color: Colors.grey.shade500)),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // أزرار التحكم
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _CircleBtn(
                      icon: Icons.replay_10_rounded,
                      size: 44,
                      iconSize: 24,
                      onTap: () => _skip(-10),
                      color: Colors.grey.shade100,
                      iconColor: Colors.grey.shade700,
                    ),
                    const SizedBox(width: 20),
                    _CircleBtn(
                      icon: isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      size: 60,
                      iconSize: 32,
                      onTap: _togglePlay,
                      color: primaryColor,
                      iconColor: Colors.white,
                    ),
                    const SizedBox(width: 20),
                    _CircleBtn(
                      icon: Icons.forward_10_rounded,
                      size: 44,
                      iconSize: 24,
                      onTap: () => _skip(10),
                      color: Colors.grey.shade100,
                      iconColor: Colors.grey.shade700,
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // أزرار السرعة
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('سرعة التشغيل',
                        style: TextStyle(
                            fontSize: 13, color: Colors.grey.shade500)),
                    Row(
                      children: [0.5, 1.0, 1.5, 2.0].map((s) {
                        final selected = _speed == s;
                        return GestureDetector(
                          onTap: () => _setSpeed(s),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            margin: const EdgeInsets.only(left: 6),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                              color: selected
                                  ? primaryColor
                                  : Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              '${s == s.roundToDouble() ? s.toInt() : s}x',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: selected
                                    ? Colors.white
                                    : Colors.grey.shade600,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ],
            ),
    );
  }
}

class _CircleBtn extends StatelessWidget {
  final IconData icon;
  final double size;
  final double iconSize;
  final VoidCallback onTap;
  final Color color;
  final Color iconColor;

  const _CircleBtn({
    required this.icon,
    required this.size,
    required this.iconSize,
    required this.onTap,
    required this.color,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        child: Icon(icon, size: iconSize, color: iconColor),
      ),
    );
  }
}
