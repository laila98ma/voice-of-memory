// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/index.dart';

import 'package:http/http.dart' as http;
import 'dart:convert';

Future<String> uploadAudioToCloudinary(FFUploadedFile? audioFile) async {
  final cloudName = 'dw2emfset';
  final uploadPreset = 'sr28jf7m';

  if (audioFile == null || audioFile.bytes == null) {
    return '';
  }

  final url =
      Uri.parse('https://api.cloudinary.com/v1_1/$cloudName/video/upload');

  final request = http.MultipartRequest('POST', url)
    ..fields['upload_preset'] = uploadPreset
    ..files.add(http.MultipartFile.fromBytes('file', audioFile.bytes!,
        filename: 'audio.m4a'));

  final response = await request.send();
  final responseData = await response.stream.bytesToString();
  final jsonData = jsonDecode(responseData);

  return jsonData['secure_url'] ?? '';
}
