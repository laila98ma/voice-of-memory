// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/actions/index.dart';

import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';

Future<String> uploadAudioToCloudinary(String? audioPath) async {
  final cloudName = 'dw2emfset';
  final uploadPreset = 'sr28jf7m';

  if (audioPath == null || audioPath.isEmpty) {
    return '';
  }

  try {
    // Read the audio file from the path
    final file = File(audioPath);
    if (!await file.exists()) {
      print('Audio file does not exist at path: $audioPath');
      return '';
    }

    final audioBytes = await file.readAsBytes();

    final url =
        Uri.parse('https://api.cloudinary.com/v1_1/$cloudName/video/upload');

    final request = http.MultipartRequest('POST', url)
      ..fields['upload_preset'] = uploadPreset
      ..files.add(http.MultipartFile.fromBytes('file', audioBytes,
          filename: 'audio.m4a'));

    final response = await request.send();
    final responseData = await response.stream.bytesToString();
    final jsonData = jsonDecode(responseData);

    return jsonData['secure_url'] ?? '';
  } catch (e) {
    print('Error uploading audio: $e');
    return '';
  }
}
